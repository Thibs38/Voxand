package com.thibsworkshop.voxand.data;

public class Entity {
    public int id;
    public String name;
    public String luaFile;
    public float speed;

}
