package com.thibsworkshop.voxand.toolbox;

import org.joml.Vector3f;

public class Line {

    public Vector3f A;
    public Vector3f B;

    public Line(Vector3f A, Vector3f B){
        this.A = A;
        this.B = B;
    }
}
