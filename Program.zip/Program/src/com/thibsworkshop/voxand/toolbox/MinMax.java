package com.thibsworkshop.voxand.toolbox;

public class MinMax {

    public int min;
    public int max;

    public MinMax(int min, int max) {
        this.min = min;
        this.max = max;
    }
}
