package com.thibsworkshop.voxand.groovy;

import com.thibsworkshop.voxand.data.Biome;
import com.thibsworkshop.voxand.loaders.JsonLoader;
import com.thibsworkshop.voxand.toolbox.Utility;
import groovy.lang.GroovyClassLoader;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;


public class LuaTest {

    public static final String path = "Program/res/data/terrain_generation/";

    public void test(){
        //JsonLoader.init();




    }

    public static void main(String[] args) {
        new LuaTest().test();
    }

}
