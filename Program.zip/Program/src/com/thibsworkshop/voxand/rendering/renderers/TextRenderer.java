package com.thibsworkshop.voxand.rendering.renderers;

import com.thibsworkshop.voxand.entities.Camera;
import com.thibsworkshop.voxand.rendering.shaders.ShaderProgram;

public class TextRenderer extends Renderer{
    public TextRenderer(ShaderProgram shader) {
        super(shader);
    }

    @Override
    public void render(Camera camera) {

    }

}
