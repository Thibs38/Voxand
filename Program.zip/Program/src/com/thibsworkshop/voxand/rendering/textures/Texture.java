package com.thibsworkshop.voxand.rendering.textures;

public class Texture {
	private final int textureID;

	public Texture(int id) {
		this.textureID = id;
	}
	
	public int getID() {
		return this.textureID;
	}

	
	
	
}
